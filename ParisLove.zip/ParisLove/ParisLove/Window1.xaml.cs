﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        private decimal balance = 100;
        private DispatcherTimer timer;
        public int Expenses = 0;
        public int Profit = 0;
        public int Win = 0;


        public Window1()
        {
            InitializeComponent();

        }
        private void UpdateBalanceText()
        {
            balanceText.Text = $"Баланс: {balance} рублей";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (balance >= 50)
            {
                balance -= 50;
                UpdateBalanceText();
                Expenses -= 50;
                Win -= 50;
                timer = new DispatcherTimer();
                timer.Tick += new EventHandler(Timer_Tick);
                timer.Interval = new TimeSpan(0, 0, 5);
                timer.Start();
            }
            else
            {
                MessageBox.Show("Денег нет");
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            balance += 10;
            Profit += 10;
            Win += 10;
            UpdateBalanceText();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (balance >= 100)
            {
                balance -= 100;
                Expenses -= 100;
                Win -= 100;
                UpdateBalanceText();
                timer = new DispatcherTimer();
                timer.Tick += new EventHandler(Timer_Tick2);
                timer.Interval = new TimeSpan(0, 0, 5);
                timer.Start();
            }
            else
            {
                MessageBox.Show("Денег нет");
            }
        }
        private void Timer_Tick2(object sender, EventArgs e)
        {
            balance += 20;
            Profit += 20;
            Win += 20;
            UpdateBalanceText();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (balance >= 150)
            {
                balance -= 150;
                UpdateBalanceText();
                Expenses -= 150;
                Win -= 150;
                timer = new DispatcherTimer();
                timer.Tick += new EventHandler(Timer_Tick3);
                timer.Interval = new TimeSpan(0, 0, 5);
                timer.Start();
            }
            else
            {
                MessageBox.Show("Денег нет");
            }
        }
        private void Timer_Tick3(object sender, EventArgs e)
        {
            balance += 30;
            Profit += 30;
            Win += 30;
            UpdateBalanceText();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Расходы {Expenses}");
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Выручка {Profit}");
        }
        
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {

            MessageBox.Show($"Чистая прибыль {Win}");
        }
    }
}
